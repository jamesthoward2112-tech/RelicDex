# RelicDex — PRU Beta 3, deploy-ready

This archive is the 444-entry approved Beta 3 website, **not yet published**.

### Sprite integrity

On GitHub Actions, `scripts/bundle_assets.py` copies vanilla **PokéSprite Gen 8 icons from the user's own fork**, pinned at SHA `c5aaa610ff2acdf7fd8e2dccd181bca8be9fcb3e`, into the website. It also copies the two supported PRL graphics donors. The program rewrites every remote sprite URL in `data/pokemon.json` to a local image path, verifies every referenced PNG exists, and aborts publication if anything breaks. All existing approved custom artwork remains unchanged.

The Seviian Noibat / Noivern forms deliberately have no art pending their approved sprites: the script will not substitute vanilla forms.

### Publishing

Create a **public** GitHub repository named `RelicDex` under `jamesthoward2112-tech`, upload the contents of this ZIP to its **main** branch, then in GitHub **Settings → Pages**, set Build and deployment source to **GitHub Actions**. The included workflow deploys `https://jamesthoward2112-tech.github.io/RelicDex/`. Do not claim the site is live until the Actions deployment succeeds and that URL is tested.

This package alone does not create a GitHub repository or configure Pages.
