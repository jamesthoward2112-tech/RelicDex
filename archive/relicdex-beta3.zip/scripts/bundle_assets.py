#!/usr/bin/env python3
"""Build a self-contained RelicDex site from approved Beta 3 and pinned sprite donors.

Requires checked out repositories from user's GitHub forks. No network operations here.
All referenced real images are copied into output (never served from remote URLs).
"""
import argparse
import json
import re
import shutil
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pokesprite', type=Path, required=True)
    ap.add_argument('--prl', type=Path, required=True)
    ap.add_argument('--out', type=Path, default=ROOT / '_site')
    args = ap.parse_args()
    out = args.out.resolve()
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    for file in list(ROOT.glob('*.html')) + [ROOT / 'manifest.webmanifest', ROOT / 'sw.js', ROOT / '.nojekyll']:
        if file.is_file():
            shutil.copy2(file, out / file.name)
    for dirname in ['css', 'js', 'data', 'assets']:
        shutil.copytree(ROOT / dirname, out / dirname)

    pokesprite = args.pokesprite.resolve()
    prl = args.prl.resolve()
    pokemon = json.loads((out / 'data/pokemon.json').read_text(encoding='utf-8'))
    copied = set()
    missing = []
    conversion_count = 0
    for mon in pokemon:
        for kind, url in list(mon.get('sprite', {}).items()):
            if not url.startswith('http'):
                continue
            parsed = urlparse(url)
            if parsed.scheme != 'https' or parsed.netloc != 'raw.githubusercontent.com':
                raise ValueError(f'Untrusted remote sprite URL: {mon["name"]} {kind}: {url}')
            bits = parsed.path.strip('/').split('/')
            if len(bits) < 5 or bits[0] != 'jamesthoward2112-tech':
                raise ValueError(f'Unexpected sprite source: {url}')
            repo = bits[1]
            rel = PurePosixPath(*bits[3:])
            if '..' in rel.parts or rel.is_absolute():
                raise ValueError(f'Invalid donor path: {rel}')
            if repo == 'pokesprite' and rel.parts[0] == 'pokemon-gen8':
                source = pokesprite.joinpath(*rel.parts)
                dest = PurePosixPath('assets/pokesprite') / rel
            elif repo == 'Pokemon-Relic-Legacy' and rel.parts[:2] == ('graphics', 'pokemon'):
                source = prl.joinpath(*rel.parts)
                dest = PurePosixPath('assets/prl') / rel
            else:
                raise ValueError(f'Unknown donor source: {url}')
            if not source.is_file():
                missing.append(f'{mon["number"]} {mon["name"]} {kind}: {source}')
                continue
            target = out.joinpath(*dest.parts)
            if dest not in copied:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
                copied.add(dest)
            mon['sprite'][kind] = dest.as_posix()
            conversion_count += 1

    # Unlike vanilla sprites, these two forms need genuine approved Seviian art.
    # Do not substitute ordinary Noibat/Noivern sprites.
    intentionally_pending = [m['name'] for m in pokemon if not m.get('sprite', {}).get('front')]
    if missing:
        raise RuntimeError(f'Sprite packaging blocked, {len(missing)} donor paths missing:\n' + '\n'.join(missing[:20]))
    remote_remaining = [(m['name'], k, v) for m in pokemon for k, v in m.get('sprite', {}).items() if v.startswith(('https:', 'http:'))]
    if remote_remaining:
        raise RuntimeError(f'Remote sprites remain: {remote_remaining[:5]}')
    broken_local = [(m['name'], k, v) for m in pokemon for k, v in m.get('sprite', {}).items() if v and not v.startswith('data:') and not (out / v).is_file()]
    if broken_local:
        raise RuntimeError(f'Missing local sprites: {broken_local[:20]}')
    (out / 'data/pokemon.json').write_text(json.dumps(pokemon, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    site_path = out / 'data/site.json'
    site = json.loads(site_path.read_text(encoding='utf-8'))
    site['published'] = True
    site['spriteDelivery'] = 'local static files only: PokéSprite fork + approved custom sprites + PRL donor'
    site['pendingArtwork'] = intentionally_pending
    site_path.write_text(json.dumps(site, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'READY: {len(pokemon)} entries, {conversion_count} references localized, {len(copied)} donor PNGs copied, {len(intentionally_pending)} approval-pending fronts: {intentionally_pending}')


if __name__ == '__main__':
    main()
