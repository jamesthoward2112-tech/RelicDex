# RelicDex approved-art policy — 16 October 2026

- Only explicitly approved Relics-series custom sprites are accepted. Approved sources: the PRL Custom Sprite Port Manifest (7 Oct corrected version), later PRU Canonical Data decisions and protected PJR/PHR graphics. The species roster alone is not proof that arbitrary donor artwork is approved.
- Latest PRU overrides legacy files: Hyenadon replaced by Skulberus; nuMew replaced by Mewsion; Bellantem/Sabellite/Sudowarden/Terathwack remain retired; Deoxys uses the approved AlteRed BYOXYS Normal-form sprite and retains other PRU forms; Donphalanx requires a check against the later approved chrome recolour, not the older Iron Treads source.
- Trainer-only forms (Lance, Rival, bosses, Rockets) never replace the globally displayed vanilla species and never count as additional Pokédex species.
- Only global art replacements explicitly marked in the PRL manifest use custom art as the default. Deoxys Normal is a separate explicit PRU BYOXYS form override, and the other Deoxys form graphics must be preserved. RELICS encounter/form art appears as a separate gallery where bundled.
- Vanilla display artwork is sourced from https://github.com/jamesthoward2112-tech/pokesprite at commit c5aaa610ff2acdf7fd8e2dccd181bca8be9fcb3e. These are 68×56 box/menu icons, **not** genuine 64×64 GBA battle sprites. The vanilla site artwork requires internet access to render; this beta does not bundle it offline.
- Pokesprite fork has Gen8 coverage; the approved newer-gen exceptions (e.g. Annihilape and Clodsire) use their approved PRL source if available; don't hallucinate a Gen8 image.
- Odyssey II, TRE 2026, Elite Redux and unapproved donor pose banks are **archives**, not automatic fallbacks.
- ROM sprite integration, encounter locations, and final Pokédex numbering are not independently ROM verified.
