# RelicDex data contract — first draft

All public `data/*.json` files are currently `[]`. The following examples describe *shapes*, not real PRU records. The completed PRU Pokédex is the source of truth.

## `data/pokemon.json`

A JSON array where entries resemble:

```json
[
  {
    "id": "species-id",
    "number": 1,
    "name": "Species Name",
    "region": "Johto",
    "types": ["Grass", "Poison"],
    "description": "Source-verified description",
    "stats": {"hp": 0, "attack": 0, "defense": 0, "spAttack": 0, "spDefense": 0, "speed": 0},
    "abilities": ["Verified ability"],
    "roles": ["Special attacker"],
    "obtainable": true,
    "availableAfterBadges": 0,
    "locations": ["Verified area/route"],
    "evolution": ["Prior form", "This form", "Next form"],
    "sprite": {
      "front": "assets/sprites/species-id/front.png",
      "back": "assets/sprites/species-id/back.png",
      "icon": "assets/sprites/species-id/icon.png"
    },
    "trainerVariants": [
      {
        "id": "trainer-specific-artwork-id",
        "trainer": {
          "id": "trainer-id",
          "name": "Trainer Display Name",
          "class": "Trainer Class",
          "portrait": "assets/trainers/trainer-id/portrait.png"
        },
        "label": "Trainer Display Name's Species Name",
        "formLabel": "Unique trainer battle art",
        "sprite": {
          "front": "assets/sprites/species-id/trainer-trainer-id/front.png",
          "back": "assets/sprites/species-id/trainer-trainer-id/back.png",
          "shiny": "assets/sprites/species-id/trainer-trainer-id/shiny.png"
        },
        "note": "Approved notes, if relevant",
        "source": "Final PRU manifest or verified ROM asset"
      }
    ],
    "recommendedSet": {
      "ability": "Verified ability",
      "item": "Verified available item",
      "moves": ["Move 1", "Move 2", "Move 3", "Move 4"],
      "explanation": "Source-checked rationale"
    }
  }
]
```

### Trainer-exclusive artwork rules

- Every `trainerVariants` array belongs **inside its original species record**. It does not add another Pokédex number or new species.
- The paired display uses `trainer.portrait` and the alternate `sprite.front`, with optional `back` and `shiny` view switches. Leave missing images absent — do not substitute normal sprites.
- Each trainer variant can have a unique `id`, trainer name, trainer class, descriptive label, and source/provenance.
- Search by trainer name should return the **parent Pokémon's entry** once, not a separate entry.
- Lance's Gyarados and the rival's Gyarados are **illustrative layout concepts**, not claims that these assets currently exist in PRU. Likewise an example number such as #165 is not canonical.
- Where a trainer's Pokémon genuinely differs in moves, held items, abilities or battle mechanics, represent that as separate **trainer-battle metadata** and not a new species unless the finished PRU Pokédex classifies it as such.

**Important:** this is an interface example only. The fake record above MUST NEVER be placed in the live `pokemon.json` or presented as approved PRU canon.

`availableAfterBadges` should be a number 0-8 for the story, 99 for postgame, if the final game uses badge-based gating. If the game's actual unlocks differ, revise this rule to match actual PRU progression rather than forcing compatibility.

Unknown moves, abilities, sprite variants and item locations must remain absent rather than fabricated. For fully verified recommended moves and items, ensure the moves can be learned and the item is available at the selected story stage. The current team engine uses `types`, `roles` and `availableAfterBadges`; it will use `recommendedSet` verbatim where available.

## `data/locations.json`

Array of `{ "name": "Location name", "region": "Region", "description": "Where/when", "method": "Grass/cave/water/fishing/gift", "pokemon": ["Species"], "requirement": "Badge or story flag" }` objects. Ensure any variant-specific spawn rate/level data is represented as needed.

## `data/items.json`

Array of `{ "name": "Item", "category": "Held item", "description": "Purpose", "location": "Specific verified source", "availability": "When obtainable", "region": "Region" }` objects.

## `data/evolutions.json`

Array of `{ "name": "From → To", "from": "Base form", "to": "Evolution", "method": "Exact method", "requirement": "Level/item/time and conditions", "region": "Region" }` objects.

## Release checklist

1. Species count and internal numbering match PRU, including which Relics are ordinary species and which are forms.
2. All front/back/icons reflect the **final approved sprite inventory**; no placeholder donor artwork is silently used.
3. Move, ability, held-item and evolution information is verified against PRU files or gameplay.
4. Every location and story gate matches the final ROM; legacy PRL/PKR/PHR/PJR routes are not assumed.
5. The Team Builder only suggests obtainable Pokémon at the chosen game stage; recommended held items and moves are actually available.
6. Confirm every trainer-only variant is linked to a parent species and both trainer portraits and Pokémon sprites are approved, without duplicate Dex entries.
7. Fully review iOS Safari, Android Chrome, desktop browsers and installed offline PWA modes before removing the WIP label.


October 16 refresh: updated from current 444-entry PRU canonical Library file. All source learnsets are provisional until ROM QA. Front sprites prioritise actual local PRU donor image bytes, then bundled PRL archived pixels, then PRL or PJR source images by existing path conventions. Internet needed for online fallback artwork. Trainer-only sprites are separate variants, not species.
